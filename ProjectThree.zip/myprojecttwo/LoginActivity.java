package com.zybooks.myprojecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameField, passwordField;
    private Button loginButton, createAccountButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        usernameField = findViewById(R.id.username);
        passwordField = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Initialize Room database
        db = AppDatabase.getDatabase(this);

        // Handle login button click
        loginButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();
            handleLogin(username, password);
        });

        // Handle create account button click
        createAccountButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();
            handleCreateAccount(username, password);
        });
    }

    // Handle login logic
    private void handleLogin(String username, String password) {
        new Thread(() -> {
            User user = db.userDao().login(username, password);
            runOnUiThread(() -> {
                if (user != null) {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.putExtra("USERNAME", username);  // Pass the username to HomeActivity
                    startActivity(intent);
                    finish();  // Close LoginActivity
                } else {
                    Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    // Handle create account logic
    private void handleCreateAccount(String username, String password) {
        new Thread(() -> {
            User existingUser = db.userDao().getUserByUsername(username);
            runOnUiThread(() -> {
                if (existingUser == null) {
                    // Insert new user and log in
                    new Thread(() -> {
                        db.userDao().insertUser(new User(username, password));
                        runOnUiThread(() -> {
                            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                            handleLogin(username, password); // Log in after account creation
                        });
                    }).start();
                } else {
                    Toast.makeText(this, "Username already exists!", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}